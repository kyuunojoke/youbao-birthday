# You Bao Birthday — Next.js + shadcn/ui

A birthday microsite built with Next.js App Router, TypeScript, Tailwind CSS v4, shadcn/ui-style source components, Radix Dialog, Lucide icons, and next-themes.

## Run locally

```bash
npm install
npm run dev
```

Then open http://localhost:3000.

## Build

```bash
npm run build
npm start
```

## Main files

- `app/page.tsx` — birthday page and interactions
- `app/globals.css` — theme tokens + animation
- `components/ui/*` — shadcn-style UI components
- `components/theme-toggle.tsx` — light/dark toggle

## Customize

Edit the birthday message in `app/page.tsx`. You can add photos later under `public/` and render them with `next/image`.
